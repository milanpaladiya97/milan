<a href="https://help.servmask.com/knowledgebase/unlimited-extension-user-guide/" target="_blank"><?php _e( 'User Guide', AI1WMUE_PLUGIN_NAME ); ?></a>
